This is not the file you are looking for.
A reasonably up-to-date version can be found at http://dygraphs.com/dygraph-combined.js

dygraph-combined.js is a "packed" version of the larger dygraphs JS files. It is
smaller and loads more quickly, but is harder to debug.

To generate this file, run "make" or generate-combined.sh.

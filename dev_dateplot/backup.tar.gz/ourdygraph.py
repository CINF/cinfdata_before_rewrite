#!/usr/bin/python

import time
import sys

class Plot():
    """ This class is used to generate the dygraph content """

    def __init__(self, options, ggs):
        """ init """

        self.o = options
        self.ggs = ggs

        self.dyg_settings = {'right_caption_suffix': ' (r)'}
        self.right_yaxis = len(self.o['right_plotlist']) > 0
        self.out = sys.stdout
        self.tab = '    '

    def new_plot(self, data, plot_info, measurement_count):
        self._header(self.out, data, plot_info)
        self._data(self.out, data, plot_info)
        self._options(self.out, data, plot_info)
        self._end(self.out, data, plot_info)
        
    def _header(self, out, data, plot_info):
        """ Form the header """

        # Write header
        out.write('g = new Dygraph(\n' +
                  self.tab + 'document.getElementById("graphdiv"),\n') 

    def _data(self, out, data, plot_info):
        """ Determine the type of the plot and print out the data in the
        appropriate way using the functions:
          _data_dateplot
          _data_xyplot
        """

        if self.ggs['default_xscale'] == 'dat':
            self._data_dateplot(out, data, plot_info)
        else:
            self._data_xyplot(out, data, plot_info)

    def _data_dateplot(self, out, data, plot_info):
        plot_n = len(self.o['left_plotlist'] + self.o['right_plotlist'])
        last_line = '\n' + self.tab + '//DATA\n'
        for n, dat in enumerate(data['left'] + data['right']):
            this_line = [''] * (plot_n + 1)
            for item in dat['data']:
                out.write(last_line)
                this_line[0] = str(time.strftime('%Y-%m-%d %H:%M:%S',
                                                 time.localtime(int(item[0]))))
                this_line[n+1] = str(item[1])
                #self.csvwriter.writerow(this_line)
                last_line = self.tab + '"' + ','.join(this_line) + '\\n" +\n'
        
        out.write(last_line.rstrip(' +\n') + ',\n\n')

    def _data_xyplot(self, out, data, plot_info):
        plot_n = len(self.o['left_plotlist'] + self.o['right_plotlist'])
        last_line = '\n' + self.tab + '//DATA\n'
        for n, dat in enumerate(data['left'] + data['right']):
            this_line = [''] * (plot_n + 1)
            for item in dat['data']:
                out.write(last_line)
                this_line[0] = str(item[0])
                this_line[n+1] = str(item[1])
                #self.csvwriter.writerow(this_line)
                last_line = self.tab + '"' + ','.join(this_line) + '\\n" +\n'
        
        out.write(last_line.rstrip(' +\n') + ',\n\n')

    def _options(self, out, data, plot_info):
        """ Form all the options and ask _output_options to print them in a
        javascript friendly way
        """

        def _q(string):
            """ _q for _quote: Utility function to add quotes to strings """
            return '\'{0}\''.format(string)

        # Form labels string
        labels = ['Date']
        for dat in data['left']:
            labels.append(dat['lgs']['caption'])
        r_ylabels=[]
        for dat in data['right']:
            labels.append(dat['lgs']['caption'] + self.dyg_settings['right_caption_suffix'])
            r_ylabels.append(dat['lgs']['caption'] + self.dyg_settings['right_caption_suffix'])

        # Initiate options variable. A group of options are contained in a list
        # and the options are given as a key value pair in in a dictionary
        # containing only one item
        options = [{'labels': str(labels)}]

        # Add second yaxis configuration
        if self.right_yaxis:
            first_label = r_ylabels[0]
            # Add first data set to secondary axis
            # Ex: 'Containment (r)': {axis: {}}
            y2options = [{'logscale': str(self.o['right_logscale']).lower()}]
            options.append({_q(first_label): [{'axis': y2options}]})
            # Add remaining datasets to secondary axis
            for label in r_ylabels[1:]:
                # Ex: 'IG Buffer (r)': {axis: 'Containment (r)'}
                a = {_q(label): [{'axis': _q(first_label)}]}
                options.append(a)
            options.append({'y2label': _q(plot_info['right_ylabel'])})

        # General options
        options += [{'logscale': str(self.o['left_logscale']).lower()},
                    {'title': _q(plot_info['title'])},
                    {'ylabel': _q(plot_info['left_ylabel'])},
                    #{'valueRange': '[0,100]'},
                    {'yAxisLabelWidth': '60'}
                    ]
        
        self._output_options(out, None, options, 1, last=True)

    def _output_options(self, out, name, options, level, last=False):
        if name is None:
            out.write(self.tab * level + '{\n')
        else:
            out.write(self.tab * level + name + ': {\n')

        for n, (key, value) in enumerate([op.items()[0] for op in options]):
            if isinstance(value, list):
                if n == len(value)-1:
                    self._output_options(out, key, value, level+1, last=True)
                else:
                    self._output_options(out, key, value, level+1, last=False)
            else:
                if n == len(options)-1:
                    out.write(self.tab*(level+1) + key + ': ' + value + '\n')
                else:
                    out.write(self.tab*(level+1) + key + ': ' + value + ',\n')
                

        if last:
            out.write(self.tab * level + '}\n')
        else:
            out.write(self.tab * level + '},\n')

    def _end(self, out, data, plot_info):
        """ Output last line """
        out.write(');')


################################################################################
# OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD OLD  #
################################################################################


    def __options(self, out, data, plot_info):
        # Labels
        labels = ['Date']
        for plot in self.o['left_plotlist']:
            labels.append(data[plot]['lgs']['caption'])
        r_ylabels=[]
        for plot in self.o['right_plotlist']:
            labels.append(data[plot]['lgs']['caption'] + self.dyg_settings['right_caption_suffix'])
            r_ylabels.append(data[plot]['lgs']['caption'] + self.dyg_settings['right_caption_suffix'])

        out.write('  {\n' +
                  '    logscale: {0},\n'.format(str(self.o['left_logscale']).lower()) +
                  #'    colors: {0},\n'.format(str(['#284785', '#EE1111', '#8AE234'])) +
                  '    title: \'{0}\',\n'.format(plot_info['title']) +
                  '    ylabel: \'{0}\',\n'.format(plot_info['left_ylabel']) +
                  '    labels: {0},\n'.format(str(labels)))

        if self.right_yaxis:
            first_label = r_ylabels[0]
            out.write('    \'' + first_label + '\': {{axis: {{logscale:{0}}}}},\n'.format(str(self.o['right_logscale']).lower()))
            for label in r_ylabels[1:]:
                out.write('    \'' + label + '\': {axis: \'' + first_label + '\'},\n')
            #out.write('    axes: {y2: {labelsKMB:true}},\n')
            out.write('    y2label: \'{0}\',\n'.format(plot_info['right_ylabel']))
            # 
            
        out.write('    yAxisLabelWidth: 60,\n'
                  '    rollPeriod: 1,\n'
                  #'    valueRange: [0,1],\n'
                  #'    xAxisHeight: 16\n'
                  '    showRoller: true\n'
                  '  }\n'
                  ');')

        #out.write('    yAxisLabelWidth: 60,\n')
        #out.write('    rollPeriod: 1,\n')
        #out.write('    showRoller: true\n')
        #out.write('  }\n')
        #out.write('  );')

    def _new_plot(self, data, plot_info, measurement_count):
        

        text = ('g = new Dygraph('
                '\n'
                '// containing div\n'
                'document.getElementById("graphdiv"),'
                '\n'
                '// CSV or path to a CSV file.\n'
                '"Date,Temperature\\n" +\n'
                '"2008-05-07,75\\n" +\n'
                '"2008-05-08,70\\n" +\n'
                '"2008-05-09,80\\n"'
                '\n'
                ');')
        
        #sys.stdout.write('hallo\nworld')
        print text#'hallo\nworld'

    def __data(self, out, data, plot_info):
        plot_n = len(self.o['left_plotlist'] + self.o['right_plotlist'])
        last_line = '\n' + self.tab + '//DATA\n'
        for n, plot in enumerate(self.o['left_plotlist'] + self.o['right_plotlist']):
            this_line = [''] * (plot_n + 1)
            for item in data[plot]['data']:
                out.write(last_line)
                this_line[0] = str(time.strftime('%Y-%m-%d %H:%M:%S',
                                                 time.localtime(int(item[0]))))
                this_line[n+1] = str(item[1])
                #self.csvwriter.writerow(this_line)
                last_line = self.tab + '"' + ','.join(this_line) + '\\n" +\n'
        
        out.write(last_line.rstrip(' +\n') + ',\n\n')

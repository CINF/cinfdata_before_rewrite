#!/usr/bin/python

from optparse import OptionParser
import sys
import hashlib

# set HOME environment variable to a directory the httpd server can write to
import os
os.environ[ 'HOME' ] = '/var/www/cinfdata/figures'
# System-wide ctypes cannot be run by apache... strange...
sys.path.insert(1, '/var/www/cinfdata')

# Matplotlib must be imported before MySQLdb (in dataBaseBackend), otherwise we
# get an ugly error
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.transforms as mtransforms
import matplotlib.dates as mdates

# Import our own classes
#from databasebackend import dataBaseBackend
from common import Color, GMT1

class Plot():
    """This class is used to generate the figures for the plots."""
    
    def __init__(self, options, ggs):
        """ Description of init """
        
        self.o = options
        self.ggs = ggs
        
        # Set the image format to standard, overwite with ggs value and again
        # options value if it exits
        if self.o['image_format'] == '':
            self.image_format = self.ggs['image_format']
        else:
            self.image_format = self.o['image_format']

        # Default values for matplotlib plots (names correspond to gs names)
        self.mpl_settings = {'right_caption_suffix': ' (r)',
                             'width': 900,
                             'height': 600,
                             'title_size': '24',
                             'xtick_labelsize': '12',
                             'ytick_labelsize': '12',
                             'legend_fontsize': '10',
                             'xlabel_fontsize': '16',
                             'ylabel_fontsize': '16'}
        
        # Owerwrite defaults with gs values and convert to appropriate types
        for key, value in self.mpl_settings.items():
            try:
                value = type(value)(self.ggs[key])
            except KeyError:
                pass
        
        # Write some settings to pyplot
        rc_temp = {'figure.figsize': [float(self.mpl_settings['width'])/100,
                                      float(self.mpl_settings['height'])/100],
                   'axes.titlesize': self.mpl_settings['title_size'],
                   'xtick.labelsize': self.mpl_settings['xtick_labelsize'],
                   'ytick.labelsize': self.mpl_settings['ytick_labelsize'],
                   'legend.fontsize': self.mpl_settings['legend_fontsize']
                   }
        plt.rcParams.update(rc_temp)
                                                        
        # Plotting options
        self.maxticks=15
        self.tz = GMT1()
        self.right_yaxis = len(self.o['right_plotlist']) > 0
        self.measurement_count = None
 
        # object to give first good color, and then random colors
        self.c = Color()

    def new_plot(self, data, plot_info, measurement_count):
        """ Form a new plot with the given data and info """
        self.measurement_count = sum(measurement_count)
        self._init_plot()
        self._plot(data)
        self._zoom()
        self._title_and_labels(plot_info)
        self._save()

    def _init_plot(self):
        """ Initialize plot """
        self.fig = plt.figure(1)

        self.ax1 = self.fig.add_subplot(111)
        if self.right_yaxis:
            self.ax2 = self.ax1.twinx()

        if self.o['left_logscale'] is True:
            self.ax1.set_yscale('log')
        if self.right_yaxis and self.o['right_logscale'] is True:
            self.ax2.set_yscale('log')

    def _plot(self, data):
        """ Determine the type of the plot and make the appropriate plot by use
        of the functions:
          _plot_dateplot
          _plot_graphplot
        """
        if self.ggs['default_xscale'] == 'dat':
            self._plot_dateplot(data)
        else:
            self._plot_graphplot(data)

    def _plot_dateplot(self, data):
        """ Make the date plot """
        # Rotate datemarks on xaxis
        self.ax1.set_xticklabels([], rotation=25, horizontalalignment='right')
        # Left axis
        for dat in data['left']:
            # Form caption
            if dat['lgs'].has_key('caption'):
                caption = dat['lgs']['caption']
            else:
                caption = None
            # Plot
            if len(dat) > 0:
                self.ax1.plot_date(mdates.epoch2num(dat['data'][:,0]),
                                   dat['data'][:,1],
                                   label=caption,
                                   xdate=True,
                                   color=self.c.get_color(),
                                   tz=self.tz,
                                   fmt='-')
        # Right axis
        for dat in data['right']:
            # Form caption
            if dat['lgs'].has_key('caption'):
                caption = (dat['lgs']['caption'] +
                           self.mpl_settings['right_caption_suffix'])
            else:
                caption = None
            # Plot
            if len(dat['data']) > 0:
                self.ax2.plot_date(mdates.epoch2num(dat['data'][:,0]),
                                   dat['data'][:,1],
                                   label=caption,
                                   xdate=True,
                                   color=self.c.get_color(),
                                   tz=self.tz,
                                   fmt='-')
        # No data
        if self.measurement_count == 0:
            y = 0.00032 if self.o['left_logscale'] is True else 0.5
            self.ax1.text(0.5, y, 'No data', horizontalalignment='center',
                          verticalalignment='center', color='red', size=60)

    def _plot_graphplot(self, data):
        raise NotImplementedError('REIMPLEMENT FOR VERSION 2')

    def _zoom(self):
        """ Apply the y zooms.
        NOTE: self.ax1.axis() return a list of bounds [xmin,xmax,ymin,ymax] and
        we reuse x and replace y)
        """
        # Left axis 
        if self.o['left_yscale_bounding'] is not None:
            self.ax1.axis(self.ax1.axis()[0:2] + self.o['left_yscale_bounding'])
        # Right axis
        if self.right_yaxis and self.o['right_yscale_bounding'] is not None:
            self.ax2.axis(self.ax2.axis()[0:2] + self.o['right_yscale_bounding'])

    def _title_and_labels(self, plot_info):
        """ Put title and labels on the plot """
        # Left ylabel
        if plot_info.has_key('left_ylabel'):
            self.ax1.set_ylabel(plot_info['left_ylabel'])
        # Right ylabel
        if self.right_yaxis and plot_info.has_key('right_ylabel'):
            self.ax2.set_ylabel(plot_info['right_ylabel'])
        # Title
        if plot_info.has_key('title'):
            self.ax1.set_title(plot_info['title'], y=1.03)
        # Legends
        if self.measurement_count > 0:
            ax1_legends = self.ax1.get_legend_handles_labels()
            if self.right_yaxis:
                ax2_legends = self.ax2.get_legend_handles_labels()
                for color, text in zip(ax2_legends[0], ax2_legends[1]):
                    ax1_legends[0].append(color)
                    ax1_legends[1].append(text)
                    
            # loc for locations, 0 means 'best'. Why that isn't deafult I
            # have no idea
            self.ax1.legend(ax1_legends[0], ax1_legends[1], loc=0)

    def _save(self):
        """ Save the figure """
        self.fig.savefig(sys.stdout, bbox_inches='tight', pad_inches=0.03,
                         format=self.o['image_format'])

        
class oldPlot():
    
    def __init__(self):
        pass

    def main(self):
        if os.path.exists(self.namehash) and False:
            print self.namehash
        else:
            # Call a bunch of functions
            self._init_plot()
            self._plot1()
            if self.left_color != 'black':
                if self.right_color != 'black':
                    self.c.color_axis(self.ax1, self.ax2, self.left_color, self.right_color)
                else:
                    self.c.color_axis(self.ax1, None, self.left_color, None)
            self._legend()
            self._zoom_and_flip()
            self._transform_and_label_axis()
            if not self.small_plot:
                self._title()
            self._grids()
            self._save()

    def _init_plot(self):
        ### Apply settings        
        # Small plots
        if self.small_plot:
            # Apply default settings 
            plt.rcParams.update({'figure.figsize':[4.5, 3.0],
                                 'ytick.labelsize':'x-small',
                                 'xtick.labelsize':'x-small',
                                 'legend.fontsize':'x-small'})
            # Overwrite with values from graphsettings
            #plt.rcParams.update(self.db.global_settings['rcparams_small'])
        else:
            plt.rcParams.update({'figure.figsize':[9.0, 6.0],
                                 'axes.titlesize':'24',
                                 'legend.fontsize':'small'})
            #plt.rcParams.update(self.db.global_settings['rcparams_regular'])

        self.fig = plt.figure(1)

        self.ax1 = self.fig.add_subplot(111)
        self.ax2 = None

        # Decide on the y axis type
        self.gs = self.db.global_settings
        if self.logscale:
            self.ax1.set_yscale('log')
        elif self.gs['default_yscale'] == 'log':
            self.ax1.set_yscale('log')
    
    def _plot1(self):
        # Make plot
        data_in_plot = False
        for data in self.db.get_data():
            if len(data['data']) > 0:
                data_in_plot = data_in_plot or True

                self.ax1.plot_date(mdates.epoch2num(data['data'][:,0]), data['data'][:,1], xdate=True,
                                   color=self.c.get_color(), tz=self.tz, fmt='-')
        
        # If no data has been been put on the graph at all, explain why there
        # is none
        if not data_in_plot:
            y = 0.00032 if self.logscale or self.gs['default_yscale'] == 'log' else 0.5
            self.ax1.text(0.5, y, 'No data', horizontalalignment='center',
                          verticalalignment='center', color='red', size=60)


    def _plot(self):
        # Make plot
        data_in_plot = False
        for data in self.db.get_data():
            if len(data['data']) > 0:
                data_in_plot = data_in_plot or True
                # Speciel case for barplots
                if self.db.global_settings.has_key('default_style') and\
                        self.db.global_settings['default_style'] == 'barplot':
                    self.ax1.bar(data['data'][:,0], data['data'][:,1],
                                 color=self.c.get_color())
                # Normal graph styles
                else:
                    # If the graph go on the right side of the plot
                    if data['info']['on_the_right']:
                        # Initialise secondary plot if it isn't already
                        if not self.ax2:
                            self._init_second_y_axis()
                        # If info has a color (i.e. it is given in gs ordering)
                        if data['info'].has_key('color'):
                            # Set the color for the graph and axis
                            color = data['info']['color']
                            if 'overview' in self.options.type:
                                self.right_color = data['info']['color']
                        else:
                            # Else get a new color from self.c
                            color = self.c.get_color()
                        
                        # Make the actual plot
                        self.ax2.plot(data['data'][:,0], data['data'][:,1],
                                      color=color,
                                      label=self._legend_item(data)+'(R)')
                    # If the graph does not go on the right side of the plot
                    else:
                        # If info has a color (i.e. it is given in gs ordering)
                        if data['info'].has_key('color'):
                            # Set the color for the graph and axis
                            color = data['info']['color']
                            if 'overview' in self.options.type:
                                self.left_color = data['info']['color']
                        else:
                            # Else get a new color from self.c
                            color = self.c.get_color()
                        
                        # Make the actual plot
                        self.ax1.plot(data['data'][:,0], data['data'][:,1],
                                      color=color,
                                      label=self._legend_item(data))
        
        # If no data has been been put on the graph at all, explain why there
        # is none
        if not data_in_plot:
            y = 0.00032 if self.logscale or self.gs['default_yscale'] == 'log' else 0.5
            self.ax1.text(0.5, y, 'No data', horizontalalignment='center',
                          verticalalignment='center', color='red', size=60)


    def _legend(self):
        if self.db.global_settings['default_xscale'] != 'dat':
            ax1_legends = self.ax1.get_legend_handles_labels()
            if self.ax2:
                ax2_legends = self.ax2.get_legend_handles_labels()
                for color, text in zip(ax2_legends[0], ax2_legends[1]):
                    ax1_legends[0].append(color)
                    ax1_legends[1].append(text)
                    
            # loc for locations, 0 means 'best'. Why that isn't deafult I
            # have no idea
            self.ax1.legend(ax1_legends[0], ax1_legends[1], loc=0)

    def _zoom_and_flip(self):
        # Now we are done with the plotting, change axis if necessary
        # Get current axis limits
        self.axis = self.ax1.axis()
        if self.options.xmin != self.options.xmax:
            self.axis = (float(self.options.xmin), float(self.options.xmax)) +\
                self.axis[2:4]
        if self.options.ymin != self.options.ymax:
            self.axis = self.axis[0:2] + (float(self.options.ymin),
                                          float(self.options.ymax))
        if self.flip_x:
            self.axis = (self.axis[1], self.axis[0]) + self.axis[2:4]
        self.ax1.axis(self.axis)
        
    def _transform_and_label_axis(self):
        """ Transform X-AXIS axis and label it """
        
        # If it is a date plot
        if self.db.global_settings['default_xscale'] == 'dat':
            # IMPLEMENT Take care of morning pressure and small plots
            markformat = '%H:%M' if self.small_plot else '%b-%d %H:%M'
            major_locator = mdates.AutoDateLocator()
            major_formatter = mdates.DateFormatter(markformat)
            self.ax1.xaxis.set_major_locator(major_locator)
            self.ax1.xaxis.set_major_formatter(major_formatter)
            ticks = self.ax1.get_xticks()
            if len(ticks) >= self.maxticks:
                reduction_factor = len(ticks)//self.maxticks + 1
                ticks = [tick for n, tick in enumerate(ticks) if n % reduction_factor == 0]
            self.ax1.set_xticks(ticks)
            self.fig.autofmt_xdate()
                        
        elif self.options.type == 'masstime':
            gs_temp_unit = self.gs['temperature_unit']
            other_temp_unit = 'C' if gs_temp_unit == 'K' else 'K'
            cur_temp_unit = other_temp_unit if self.shift_temp_unit else\
                gs_temp_unit
            if self.as_function_of_t and not self.small_plot:
                self.ax1.set_xlabel(self.gs['t_xlabel'] + cur_temp_unit)
            elif not self.small_plot:
                self.ax1.set_xlabel(self.gs['xlabel'])
        elif self.options.type == 'xps':
            if self.shift_be_ke and not self.small_plot:
                self.ax1.set_xlabel(self.gs['alt_xlabel'])
            elif not self.small_plot:
                self.ax1.set_xlabel(self.gs['xlabel'])
        elif not self.small_plot:
            self.ax1.set_xlabel(self.gs['xlabel'])
        
        # Label Y-axis
        if not self.small_plot:
            self.ax1.set_ylabel(self.gs['ylabel'], color=self.left_color)
            if self.ax2:
                self.ax2.set_ylabel(self.gs['right_ylabel'], color=self.right_color)

    def _title(self):
        """ TITLE """
        # Set the title and raise it a bit
        if self.as_function_of_t:
            self.bbox_title = self.ax1.set_title(
                self.gs['t_title'], y=1.03)
        else:
            self.bbox_title = self.ax1.set_title(
                self.gs['title'], y=1.03)
            
    def _grids(self):
        # GRIDS
        self.ax1.grid(b=True, which = 'major')
        #plt.xscale('linear')
        #plt.xticks(range(0,100,10))
        #plt.x_minor_ticks(range(0,100,10))
        #plt.grid(b='on', which='minor')
        #plt.grid(b='on', which='major')

    def _save(self):
        ## Filesave
        # Save
        self.fig.savefig(self.namehash, bbox_inches='tight', pad_inches=0.03)

        # This is the magical line that plot.php opens
        # For the script to work this has to be the only print statement
        print self.namehash

    ### Here start the small helper functions that are called from the main flow

    def _init_second_y_axis(self):
        self.ax2 = self.ax1.twinx()
        if self.db.global_settings['right_yscale'] == 'log':
            self.ax2.set_yscale('log')

    def _legend_item(self, data):
        if self.db.global_settings['default_xscale'] == 'dat':
            return ''
        elif data['gs'].has_key('legend_field_name') and\
                data['info'][data['gs']['legend_field_name']]:
            return data['info']['mass_label'] + '-' + str(data['info']['id'])
        else:
            return str(data['info']['id'])

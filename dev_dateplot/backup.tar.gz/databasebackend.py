#!/usr/bin/python

# db
import MySQLdb
from scipy import array
from scipy.interpolate import interp1d
#from time import mktime
from datetime import datetime
from graphsettings import graphSettings

class dataBaseBackend():
    ''' This class will fetch measurement data and measurement information from the
    database.
    '''
    def __init__(self, options, ggs):
        # From init
        self.o = options
        self.ggs = ggs
        # A few covinience assigments
        self.type_ = options['type']
        self.from_to_dict = {'from': self.o['from_to'][0],
                             'to': self.o['from_to'][1]}
        self.plotlist = self.o['left_plotlist'] + self.o['right_plotlist']


        # Create MySQL session and cursor
        db = MySQLdb.connect(user="cinf_reader",
                             passwd="cinf_reader",
                             db="cinfdata")
        self.cursor = db.cursor()

    def get_data_count(self):
        """ Determin plot type and return data count by means of the functions:
          _get_data_count_dateplot
          _get_data_count_xyplot
        """
        out = []
        # If it is a dateplot
        if self.ggs['default_xscale'] == 'dat':
            out = self._get_data_count_dateplot(out)
        else:
            out = self._get_data_count_xyplot(out)
        return out

    def _get_data_count_dateplot(self, out):
        """ Get data count for date plots """
        self.gs = graphSettings(self.type_, params=self.from_to_dict).settings
        for plot_n in self.plotlist:
            query = self.gs['dateplot' + str(plot_n)]['query']
            query = 'select count(*) ' + query[query.lower().find('from'):]
            out.append(self._result_from_query(query)[0][0])
        return out

    def _get_data_count_xyplot(self, out):
        """ Get data count for graph plots """
        for plot_n in self.plotlist:
            self.gs = graphSettings(self.type_, params={'id': plot_n}).settings
            query = self.gs['queries']['default']
            query = 'select count(*) ' + query[query.lower().find('from'):]
            out.append(self._result_from_query(query)[0][0])
        return out

    def get_data(self):
        """ Determin plot type and return data by means of the functions:
          _get_data_dateplot
          _get_data_xyplot
        """
        data = {'left': [], 'right': []}
        if self.ggs['default_xscale'] == 'dat':
            data = self._get_data_dateplot(data)
        else:
            data = self._get_data_xyplot(data)
        return data

    def _get_data_dateplot(self, data):
        """ Get data for date plots """
        self.gs = graphSettings(self.type_, params=self.from_to_dict).settings
        for side in ['left', 'right']:
            for plot_n in self.o[side + '_plotlist']:
                # lgs is the local (specific) graphsettings
                lgs = self.gs['dateplot' + str(plot_n)]
                data[side].append(
                    {'key': 'dateplot' + str(plot_n),
                     'gs': self.gs,
                     'lgs': lgs,
                     'data': array(self._result_from_query(lgs['query']))
                     })
        return data

    def _get_data_xyplot(self, data):
        """ Get data for the graph plots """
        self.gs = graphSettings(self.type_).settings
        for side in ['left', 'right']:
            for plot_n in self.o[side + '_plotlist']:
                # lgs is the local (specific) graphsettings
                lgs = graphSettings(self.type_, params={'id': plot_n}).settings
                meta_info = self._get_meta_info(lgs)

                # Get the right query: Look if the value of the column defined
                # in graphsettings have the right value to use a special query,
                # otherwise use the default one
                query = lgs['queries']['default']
                for k, v in lgs['queries'].items():
                    if k.find('extra') == 0:
                        if v['match'] == meta_info[lgs['queries']['column']]:
                            query = v['query']

                data[side].append(
                    {'key': 'dateplot' + str(plot_n),
                     'gs': self.gs,
                     'lgs': lgs,
                     'meta': meta_info,
                     'data': array(self._result_from_query(query))
                     })
        return data

    def _get_meta_info(self, lgs):
        # Fetch table headers from measurements table
        query = "DESCRIBE {0}".format(lgs['measurements_table'])
        self.meas_table_headers = self._result_from_query(query)
        
        #for n, datum in enumerate(self.data):
        # Fetch measurements table values
        query = "SELECT * FROM {0} WHERE ID = {1}".format(
            lgs['measurements_table'],
            lgs['id'])

        table_contents = self._result_from_query(query)

        # Combine table headers and values into a dictionary
        return dict(
            [[header[0], value] for header, value in
             zip(self.meas_table_headers, table_contents[0])])

#        for idl in self.id_list:
#            # Reset return varaibles
#            self.data = None; self.gs = None; self.info = {}
#            self.params = self.from_to.copy()
#            self.params['id'] = idl
#            self.gs = graphSettings(self.type_, params=self.params).settings
#            self.data = array(self._result_from_query(self.gs['query']))
#            self.info = self._get_info()
#            
#            # Determine if it should go on the right y axis
#            if self.gs.has_key('right_y_axis_field_value'):
#                names_on_the_right = [element.lower().strip() for element
#                                      in self.gs['right_y_axis_field_value'].split(',')]
#                if self.info[self.gs['right_y_axis_field_name']].lower() in names_on_the_right:
#                    self.info['on_the_right'] = True
#                else:
#                    self.info['on_the_right'] = False
#            else:
#                self.info['on_the_right'] = False
#                
#            # process_data() acts on self.data
#            self._process_data(idl)
#            yield {'data':self.data, 'gs':self.gs, 'info': self.info}


        
    def _result_from_query(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def _process_data(self, idl):
        # Here we do data manipulation if requested
        if self.type_ == "massspectrum":
            # This function acts on the self.data variable
            self._displace_negative(idl)
        elif self.type_ == "xps":
            # Shift between BE and KE if requested
            if self.shift_be_ke:
                self._shift_be_ke()
            #excitation_energy
            pass
        elif self.type_ == "masstime":
            # Shift x from time to temperature is requested
            if self.as_function_of_t:
                self._as_function_of_t(idl)
                if self.shift_temp_unit:
                    self._shift_temp_unit()
    
    ### Function that does data manipulation ###

    def _displace_negative(self, idl):
        # Apply the offset provided from php to the values
        if self.offsets[idl] != '0':
            self.data[:,1] = self.data[:,1] + float(self.offsets[idl])
            # Add warning about the operation to export
            self.gs['warning0'] = ('WARNING: ' + str(self.offsets[idl]) +
                                   ' have been added to all values to avoid '
                                   'unplottable values')
            

    def _as_function_of_t(self, idl):
        # Get the datetime of the measurement
        query = ('SELECT time FROM {0} where id = {1}'
                 ''.format(self.gs['measurements_table'], idl))
        # datetime object
        datetime = self._result_from_query(query)[0][0]

        # Fetch all sets of id and label that is from the same time
        query = ('SELECT id, mass_label FROM {0} WHERE TIME = \"{1}\"'
                 ''.format(self.gs['measurements_table'],
                           datetime.strftime("%Y-%m-%d %H:%M:%S")))
        measurements = self._result_from_query(query)

        # Find the one that has a label that contains "temperature"
        temperature_id=None
        for measurement in measurements:
            if measurement[1].lower().count('temperature') > 0:
                temperature_id = measurement[0]
        
        # If there is a temperature (that is not None)
        if temperature_id:
            # Fetch the pertaining temperature data
            query = self.gs['t_query'].format(t_id=temperature_id)
            temperature_data = array(self._result_from_query(query))
            """ Assumes both self.data (mass) and temperature_data
            (temperature) contains a common x-axis (typical time) and
            transforms the y-axis temperature_data into the x-axis of the
            self.data
            """
            x_axis = interp1d(temperature_data[:,0],temperature_data[:,1])
            
            # Cut of the ends of self.data where we have no interpolation data
            start=0; end=self.data.shape[0]
            ttmin = temperature_data[:,0].min()
            ttmax = temperature_data[:,0].max()
            uncut = (start, end)
            while self.data[start,0] < ttmin:
                start += 1
            while self.data[end-1,0] > ttmax:
                end -= 1
            if (start, end) != uncut:
                self.data = self.data[start:end,:]

            # Transform the axis
            self.data[:,0] = x_axis(self.data[:,0])

        # Add warning about the operation to export
        self.gs['warning1'] = ('WARNING: This data has been transformed to '
                               'contain values as a function of temperature')

    def _shift_temp_unit(self):
        if self.gs['temperature_unit'] == 'C':
            self.data[:,0] = self.data[:,0] + self.c_to_k
        elif self.gs['temperature_unit'] == 'K':
            self.data[:,0] = self.data[:,0] - self.c_to_k
            
        # Add warning about the operation to export
        self.gs['warning2'] = ('WARNING: The temperature data in this dataset '
                               'has had its unit shifted')

    def _shift_be_ke(self):
        # Get the excitation energy from the info (from db)
        if self.info.has_key('excitation_energy'):
            try:
                ee = float(self.info['excitation_energy'])
            except TypeError:
                raise SystemExit('In order to shift between BE and KE '
                                 'the \"excitation_energy\" field in your '
                                 'measurements table must be filled in\n\n'
                                 'Exiting')
        else:
            raise SystemExit('In order to shift between BE and KE your '
                             'measurements table must contain a '
                             '\"excitation_energy\" field.\n\nExiting')
        # Get the info about whether be or ke has been saved in db
        if self.gs.has_key('in_db'):
            in_db = self.gs['in_db']
        else:
            raise SystemExit('In order to shift between BE and KE you must '
                             'must fill in the \"in_db\" field with be or ke '
                             'in graphsettings to tell the system which has '
                             'been saved to the database.\n\nExiting')
        # Shift from be to ke
        if in_db == 'be' or in_db == 'ke':
            # KE = ee - BE   or   BE = ee - KE
            self.data[:,0] = ee - self.data[:,0]
            self.gs['warning3'] = ('WARNING: The energy data in this dataset '
                                   'has been shifted from ' + in_db)
        else:
            raise SystemExit('In order to shift between BE and KE you must '
                             'must fill in the \"in_db\" field with be or ke '
                             'in graphsettings to tell the system which has '
                             'been saved to the database.\n\nExiting')

#!/usr/bin/python

from optparse import OptionParser
import sys
from time import strptime, strftime, time, localtime

# set HOME environment variable to a directory the httpd server can write to
import os
os.environ[ 'HOME' ] = '/var/www/cinfdata/figures'
# System-wide ctypes cannot be run by apache... strange...
sys.path.insert(1, '/var/www/cinfdata')

# Matplotlib must be imported before MySQLdb (in dataBaseBackend), otherwise we
# get an ugly error
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#import matplotlib.transforms as mtransforms
#import matplotlib.dates as mdates

# Import our own classes
from databasebackend import dataBaseBackend
#from common import Color, GMT1
from graphsettings import graphSettings
import ourmatplotlib, ourdygraph


class Plot():
    """This class is used to generate the figures for the plots."""
    
    def __init__(self):
        """ Description of init """

        # Create optionparser
        parser = OptionParser()

        # Add the options to the option parser
        # Option help at https://cinfwiki.fysik.dtu.dk/cinfwiki/Software/
        # DataWebPageDeveloperDocumentation#plot.py
        parser.add_option('--type')                  # String option
	parser.add_option('--boolean_options')       # Boolean options
	parser.add_option('--left_plotlist')         # int list
	parser.add_option('--right_plotlist')        # int list
	parser.add_option('--xscale_bounding')       # Float pair
	parser.add_option('--left_yscale_bounding')  # Float pair
	parser.add_option('--right_yscale_bounding') # Float pair
	parser.add_option('--from_to')               # Time stamp pair NOT HANDLED
	parser.add_option('--image_format')          # String options

        # Parse the options
        (options, args) = parser.parse_args()

        ### Process options into self.o -  all options are given as strings,
        ### and they need to be converted into other data types
        self.o = {}
        # Parse boolean options
        for pair in options.boolean_options.split(',')[1:]:
            key, value = pair.split(':')
            self.o[key] = True if value == 'checked' else False
        # Parse bounds
        for bound in ['xscale_bounding',
                      'left_yscale_bounding',
                      'right_yscale_bounding']:
            if options.__dict__[bound] not in ['', '0,0', ',']:
                self.o[bound] = tuple(
                    [float(b) for b in options.__dict__[bound].split(',')]
                    )
            else:
                self.o[bound] = None
        # Parse lists
        for plotlist in ['left_plotlist', 'right_plotlist']:
            # List comprehension, split list string up and turn into integer
            # and add to new list, but only of > 0
            self.o[plotlist] = [int(a) for a in 
                                options.__dict__[plotlist].split(',')[1:]
                                if int(a) > 0]
        # Parse string options
        for key in ['type', 'image_format']:
            self.o[key] = options.__dict__[key]
        # From_to
        self.o['from_to'] = options.from_to.split(',')
        ### Done processing options

        # If a dateplot and called without (valid) datetimes fill them in
        try:
            strptime(self.o['from_to'][0], '%Y-%m-%d  %H:%M')
            strptime(self.o['from_to'][1], '%Y-%m-%d  %H:%M')
        except ValueError:
            # [now-1d, now]
            self.o['from_to'][0] = strftime('%Y-%m-%d  %H:%M',
                                            localtime(time()-24*3600))
            self.o['from_to'][1] = strftime('%Y-%m-%d  %H:%M')

        # Get a (g)eneral (g)raph (s)ettings object
        # (Are not polulated with data set specific values) 
        self.ggs = graphSettings(self.o['type']).settings

        ### Create database backend object
        self.db = dataBaseBackend(options=self.o, ggs=self.ggs)

        # Ask self.db for a measurement count
        self.measurement_count = self.db.get_data_count()

        self.defaults = {}
        
    def main(self):
        # Import the plotting engine appropriate for the plot type
        if self.o['matplotlib'] is True:
            self.plot = ourmatplotlib.Plot(options=self.o, ggs=self.ggs)
        else:
            self.plot = ourdygraph.Plot(options=self.o, ggs=self.ggs)
        self.new_plot()

    def new_plot(self):
        """ To form a new plot we first:
        1) Fetch the data
        2) Determine the title
        3) Determine the label
        4) Ask the plotting engine to make the plot
        """
        self.data = self.db.get_data()
        self.plot_info = self.titles_and_labels(self.data)
        return self.plot.new_plot(self.data, self.plot_info,
                                  self.measurement_count)

    def titles_and_labels(self, data):
        """ Determin plot type and find titles and labels from the functions:
          _titles_and_labels_dateplot                                                                                                 
          _titles_and_labels_xyplot
        """
        if self.ggs['default_xscale'] == 'dat':
            titles_n_labels = self._titles_and_labels_dateplot(data)
        else:
            titles_n_labels = self._titles_and_labels_xyplot(data)

        return titles_n_labels

    def _titles_and_labels_dateplot(self, data, titles_n_labels={}):
        """ Determine title and labels for a date plot"""
        # Fall backs
        title_fall_back =\
            self.ggs['title'] if self.ggs.has_key('title') else ''
        ylabel_fall_back =\
            self.ggs['ylabel'] if self.ggs.has_key('ylabel') else ''

        # Title
        # Pull out a title candidate for each of the data graphs
        title_cand = [v['lgs']['title'] for v in data['left'] + data['right']]
        # .. and reduce to one candidate
        titles_n_labels['title'] =\
            self._reduce_candidates(title_cand, title_fall_back)

        # Same procedure for Y-labels
        left_ylabel_cand =\
            [v['lgs']['ylabel'] for v in data['left']]
        right_ylabel_cand =\
            [v['lgs']['ylabel'] for v in data['right']]
        titles_n_labels['left_ylabel'] = self._reduce_candidates(
            left_ylabel_cand, ylabel_fall_back)
        titles_n_labels['right_ylabel'] = self._reduce_candidates(
            right_ylabel_cand, ylabel_fall_back)

        return titles_n_labels

    def _titles_and_labels_xyplot(self, data, titles_n_labels={}):
        """ Determine title and labels for a xyplot """
        titles_n_labels['title'] = self.ggs['title']
        titles_n_labels['left_ylabel'] = 'left'
        titles_n_labels['right_ylabel'] = 'right'
        return titles_n_labels
        ### FIXME FIXME FIXME   FINISH IMPLEMENTATIN  FIXME FIXME FIXME###
        #ylabel_fall_back =\
        #    self.ggs['ylabel'] if self.ggs.has_key('ylabel') else ''

        #raise NotImpementedError('REIMPLEMENT FOR VERSION 2')

    def _reduce_candidates(self, candidates, fall_back):
        """ Utility function to reduce a list of candidates and a fall-back to
        one value
        """
        if len(candidates) == 0:
            return fall_back
        else:
            if [candidates[0]]*len(candidates) == candidates:
                return candidates[0]
            else:
                return fall_back        

if __name__ == "__main__":
    plot = Plot()
    plot.main()

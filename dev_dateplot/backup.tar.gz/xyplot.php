<?php
  /*
    Copyright (C) 2012 Robert Jensen, Thomas Anderser and Kenneth Nielsen
    
    The CINF Data Presentation Website is free software: you can
    redistribute it and/or modify it under the terms of the GNU
    General Public License as published by the Free Software
    Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    The CINF Data Presentation Website is distributed in the hope
    that it will be useful, but WITHOUT ANY WARRANTY; without even
    the implied warranty of MERCHANTABILITY or FITNESS FOR A
    PARTICULAR PURPOSE.  See the GNU General Public License for more
    details.
    
    You should have received a copy of the GNU General Public License
    along with The CINF Data Presentation Website.  If not, see
    <http://www.gnu.org/licenses/>.
  */

include("graphsettings.php");
include("../common_functions.php");

$db = std_db();
$type = $_GET["type"];
$settings = plot_settings($type);


// Simple function to replicate PHP 5 behaviour
function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

// If graphsettings.xml do not have a specific grouping column setting we will default to "time"
if(in_array("grouping_column",array_keys($settings)) != "1"){
 $settings["grouping_column"] = "time";
}

// Get all available measurements to populate selection boxes
$query = "SELECT distinct " . $settings["grouping_column"] . ", comment FROM " .  $settings["measurements_table"] . " where type = " . $settings["type"] . " order by time desc, id limit 800";
$result  = mysql_query($query,$db);
  while ($row = mysql_fetch_array($result)){
    $datelist[] = $row[0];
    $commentlist[] = $row[1];
    //$masslabellist[] = $row[2];
  }

//Get the id-number and timestamp of the newest measurement
$query = "SELECT id, time FROM " . $settings["measurements_table"] . " where type = " . $settings["type"] . " order by time desc limit 1";
$latest_id = single_sql_value($db,$query,0);
$latest_time = single_sql_value($db,$query,1);


//$chosen_group is the list of timestamps that is currently active. This is either the timestamplist from the url or the latest measurement
#$error_reporting_value = error_reporting(0); # Disable error reporting
$chosen_group = (no_error_get($_GET, "chosen_group") == "") ? array($latest_time) : $_GET["chosen_group"];
#error_reporting($error_reporting_value); # Re-enable error reporting
$sql_times = "";
foreach($chosen_group as $time){
    $sql_times = $sql_times . "\"" . $time . "\",";
}
$sql_times  = substr($sql_times, 0, -1);  // Remove the trailing comma

//Create the list of individual components of the chosen measurements
$query = "SELECT id, time, mass_label FROM " .  $settings["measurements_table"] . " where time in (" . $sql_times . ") order by time desc, id limit 800";
$result  = mysql_query($query,$db);
while ($row = mysql_fetch_array($result)){
    $individ_idlist[] = $row[0];
    $individ_datelist[] = $row[1];
    $individ_labellist[] = $row[2];
}

# Disable error reporting
$error_reporting_value = error_reporting(0); 

# Remember settings after submitting
$from              = ($_GET["from"]              == "") ? 0 : $_GET["from"];
$to                = ($_GET["to"]                == "") ? 0 : $_GET["to"];
$left_ymax         = ($_GET["left_ymax"]         == "") ? 0 : $_GET["left_ymax"];
$left_ymin         = ($_GET["left_ymin"]         == "") ? 0 : $_GET["left_ymin"];
$right_ymax        = ($_GET["right_ymax"]        == "") ? 0 : $_GET["right_ymax"];
$right_ymin        = ($_GET["right_ymin"]        == "") ? 0 : $_GET["right_ymin"];
$left_logscale     = ($_GET["left_logscale"]     == "") ? "" : "checked";
$right_logscale    = ($_GET["right_logscale"]    == "") ? "" : "checked";
$left_plotlist     = ($_GET["left_plotlist"]     == "") ? "" : $_GET["left_plotlist"];
$right_plotlist    = ($_GET["right_plotlist"]    == "") ? "" : $_GET["right_plotlist"];
$matplotlib        = ($_GET["matplotlib"]        == "") ? "" : "checked";
$flip_x            = ($_GET["flip_x"]            == "") ? "" : "checked";
$diff_left_y       = ($_GET["diff_left_y"]       == "") ? "" : "checked";
$diff_right_y      = ($_GET["diff_right_y"]      == "") ? "" : "checked";
$linscale_x0       = ($_GET["linscale_x0"]       == "") ? "" : "checked";
$linscale_x1       = ($_GET["linscale_x1"]       == "") ? "" : "checked";
$linscale_x2       = ($_GET["linscale_x2"]       == "") ? "" : "checked";
$linscale_left_y0  = ($_GET["linscale_left_y0"]  == "") ? "" : "checked";
$linscale_left_y1  = ($_GET["linscale_left_y1"]  == "") ? "" : "checked";
$linscale_left_y2  = ($_GET["linscale_left_y2"]  == "") ? "" : "checked";
$linscale_right_y0 = ($_GET["linscale_right_y0"] == "") ? "" : "checked";
$linscale_right_y1 = ($_GET["linscale_right_y1"] == "") ? "" : "checked";
$linscale_right_y2 = ($_GET["linscale_right_y2"] == "") ? "" : "checked";


# Generate URL for figure ...
$plot_php_line = 'plot.php?type=' . $type;
$options = array('from', 'to',
		 'left_ymax', 'left_ymin',
		 'right_ymax', 'right_ymin', 
		 'left_logscale', 'right_logscale',
		 'matplotlib');
# ... add values ...
foreach($options as $value){
  $plot_php_line .= '&' . $value . '=' . str_replace(' ', '+', $$value);
}
# ... and lists ...
foreach(array('left_plotlist', 'right_plotlist') as $value){
  foreach($$value as $id){
    $plot_php_line .= '&' . $value . '[]=' . $id;
  }
}
# ... and append imageformat to them
$plot_php_line_graph = $plot_php_line . '&image_format=' . $settings['image_format'];
$plot_php_line = $plot_php_line . '&image_format=' . 'png';

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>CINF data logging</title>
    <link rel="StyleSheet" href="style.css" type="text/css" media="screen">
    <script type="text/javascript" src="dygraph/dygraph-dev.js"></script>
    <script type="text/javascript">
     // method to update selection boxes dynamically when chosing measurement
     function showData(str){
      var formLength = document.forms[0].elements.length-1;
      var options = document.forms[0].elements[formLength].options;
      var i;
      var newstr = "";
       for (i=0;i<options.length;i++){
        if (document.forms[0].elements[formLength].options[i].selected){
            newstr = newstr +  "&chosen_group[]=" + document.forms[0].elements[formLength].options[i].value;
        }
      }
      if (str==""){
        document.getElementById("measurementsLeft").innerHTML=""; //no output if empty
        document.getElementById("measurementsRight").innerHTML="";
        return;
      }
 
      if (window.XMLHttpRequest){
        xmlhttp = new XMLHttpRequest();
      }

      xmlhttp.onreadystatechange = function(){
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200){ // readyState ok
            document.getElementById("measurementsLeft").innerHTML=xmlhttp.responseText;
            document.getElementById("measurementsRight").innerHTML=xmlhttp.responseText;
        }
      }
      xmlhttp.open("GET","get_components.php?type=masstime"+newstr,true); //retrieve data from MySQL using PHP
      xmlhttp.send();    
     }

     // method to toogle lists when clicking on links
     function toggle(list){ 
      var listElementStyle=document.getElementById(list).style;
      if (listElementStyle.display=="none"){ 
        listElementStyle.display="block"; 
      }
      else{listElementStyle.display="none"; 
      } 
     }
    </script>
  </head>
  <body>
    <div class="container">
      <div class="caption">
	Data viewer<a href="/"><img class="logo" src="cinf_logo_beta_greek.png" alt="CINF data viewer"></a>
      </div>
       <div class="plotcontainer">
	<?php 
            if ($matplotlib == 'checked'){
	       echo('<a href="' . $plot_php_line_graph . '">');
	       echo('<img src="' . $plot_php_line . '"/>');
	       echo('</a>');
	    } else {
               echo('<div id="graphdiv" class="dydiv"> </div>');
	       echo('<script type="text/javascript" src=' . $plot_php_line . '></script>');
	       #$content = file_get_contents($plot_php_line);
	       #echo($content);
	    }
        ?>
       </div>
      <hr>
      <form action="xyplot.php" method="get">
	<input type="hidden" name="type" value="<?php echo($type);?>">
	<table class="generaloptions">
	  <tr>
	    <td>
	      <select name="dateselection">
		<option value="1">1 day back</option>
		<option value="2">2 days back</option>
		<option value="3">3 days back</option>
	      </select>
	    </td>
	    <td>
	      <b>From:</b><input name="from" type="text" value="<?php echo($from);?>" size="13">
	    </td>
	    <td>
	      <b>To:</b><input name="to" type="text" value="<?php echo($to);?>" size="13">
	    </td>
	    <td>
	      <a href="export_data.php">Export current data</a>
	    </td>
	    <td>
	      <input type="submit" value="Update">
	    </td>
	  </tr>
          <?php
          // Check for specific settings defined in graphsettings.xml and print if defined
            echo("<tr>");
            if(in_array("flip_x",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["flip_x"]["gui"] . "</b><input type=\"checkbox\" name=\"flip_x\" value=\"checked\"" . $flip_x . ">");
             echo("</td>");
            }
            if(in_array("as_function_of",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["as_function_of"]["gui"] . "</b><input type=\"checkbox\" name=\"as_function_of\" value=\"checked\"" . $as_function_of . ">");
             echo("</td>");
            }
            if(in_array("diff_left_y",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["diff_left_y"]["gui"] . "</b><input type=\"checkbox\" name=\"diff_left_y\" value=\"checked\"" . $diff_left_y . ">");
             echo("</td>");
            }
            if(in_array("diff_right_y",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["diff_right_y"]["gui"] . "</b><input type=\"checkbox\" name=\"diff_right_y\" value=\"checked\"" . $diff_right_y . ">");
             echo("</td>");
            }
            if(in_array("linscale_x0",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_x0"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_x0\" value=\"checked\"" . $linscale_x0 . ">");
             echo("</td>");
            }
            if(in_array("linscale_x1",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_x1"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_x1\" value=\"checked\"" . $linscale_x1 . ">");
             echo("</td>");
            }
            if(in_array("linscale_x2",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_x2"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_x2\" value=\"checked\"" . $linscale_x2 . ">");
             echo("</td>");
            }
            if(in_array("linscale_left_y0",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_left_y0"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_left_y0\" value=\"checked\"" . $linscale_left_y0 . ">");
             echo("</td>");
            }
            if(in_array("linscale_left_y1",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_left_y1"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_left_y1\" value=\"checked\"" . $linscale_left_y1 . ">");
             echo("</td>");
            }
            if(in_array("linscale_left_y2",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_left_y2"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_left_y2\" value=\"checked\"" . $linscale_left_y2 . ">");
             echo("</td>");
            }
            if(in_array("linscale_right_y0",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_right_y0"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_right_y0\" value=\"checked\"" . $linscale_right_y0 . ">");
             echo("</td>");
            }
            if(in_array("linscale_right_y1",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_right_y1"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_right_y1\" value=\"checked\"" . $linscale_right_y1 . ">");
             echo("</td>");
            }
            if(in_array("linscale_right_y2",array_keys($settings)) == "1"){
             echo("<td>");
               echo("<b>" . $settings["linscale_right_y2"]["gui"] . "</b><input type=\"checkbox\" name=\"linscale_right_y2\" value=\"checked\"" . $linscale_right_y2 . ">");
             echo("</td>");
            }
            echo("</tr>");
          ?>
          <tr>
	    <td>
	      <b>Matplotlib</b><input type="checkbox" name="matplotlib" onClick="javascript:toggle('matplotlib')" value="checked" <?php echo($matplotlib);?>>
	    </td>
          </tr>
          <tr>
            <td colspan="3">
              <span id="matplotlib" style="display:none">
                <b>Title: </b><input name="title" type="text" size="15"><br>
                <b>x-label: </b><input name="xlabel" type="text" size="15"><br>
                <b>Left y-label: </b><input name="left_ylabel" type="text" size="15"><br>
                <b>Right y-label: </b><input name="right_ylabel" type="text" size="15">
              </span>
            </td>
          </tr>
	</table>
	<hr>
	<table class="selection">
	  <tr>
	    <td><!--LEFT Y-->
	      <b>Log-scale</b><input type="checkbox" name="left_logscale" value="checked" <?php echo($left_logscale);?>><br>
	      <b>Y-Min:</b><input name="left_ymin" type="text" size="7" value="<?php echo($left_ymin);?>"><br>
	      <b>Y-Max:</b><input name="left_ymax" type="text" size="7" value="<?php echo($left_ymax);?>"><br>
	      <b>Select measurement (left y-axis):</b><br>
              <div id="measurementsLeft">
	        <select multiple size="8" name="left_plotlist[]">
                  <?php
                     # Creation of plotlist for left axis
		     for($i=0;$i<count($individ_idlist);$i++){
                        $selected = (in_array($individ_idlist[$i],$plotted_ids)) ? "selected" : "";
                        echo("<option value=\"" . $individ_idlist[$i] . "\" " . $selected . ">" . $individ_datelist[$i] . ": " . $individ_labellist[$i] . "</option>\n");
                     }
		  ?>
	        </select>
              </div>
	    </td>
	    <!--
	       <td align="center">
		 center column - currently empty
	       </td>
	    -->
	    <td align="right"><!--RIGHT Y-->
	      <b>Log-scale</b><input type="checkbox" name="right_logscale" value="checked" <?php echo($right_logscale);?>><br>
	      <b>Y-Min:</b><input name="right_ymin" type="text" size="7" value="<?php echo($right_ymin);?>"><br>
	      <b>Y-Max:</b><input name="right_ymax" type="text" size="7" value="<?php echo($right_ymax);?>"><br>
	      <b>Select measurement (right y-axis):</b><br>
              <div id="measurementsRight">
	        <select multiple size="8" name="right_plotlist[]" id="right_plotlist">
		  <!--<option value="0">None</option>-->
                  <?php
                     # Creation of plotlist for right axis
		     for($i=0;$i<count($individ_idlist);$i++){
                        $selected = (in_array($individ_idlist[$i],$plotted_ids)) ? "selected" : "";
                        echo("<option value=\"" . $individ_idlist[$i] . "\" " . $selected . ">" . $individ_datelist[$i] . ": " . $individ_labellist[$i] . "</option>\n");
                     }
		  ?>
	        </select>
              </div>
	    </td>
	  </tr>
          <tr>
            <td colspan="2"><!--LIST OF MEASUREMENTS-->
	     <b>Select measurement:</b><br>
             <select class="select" name="chosen_group[]" id="chosen_group" multiple size="8" onChange="showData(this.value)">
              <?php
                for($i=0;$i<count($datelist);$i++){
                    $selected = (in_array($datelist[$i],$chosen_group)) ? "selected" : "";
                    echo("<option value=\"" . $datelist[$i] . "\" " . $selected . ">" . $datelist[$i] . ": " . $commentlist[$i] . "</option>\n");
                }
              ?>
             </select>
            </td>
          </tr>
	</table>
      </form>
      
      <hr>

      <div class="additionalinfo">
	<h2><a href="javascript:toggle('sqlinfo')">SQL info</a></h2>
	<div id="sqlinfo" style="display:none">
	  <b>Sql-statement for this graph:</b><br>
	  SELECT unix_timestamp(time), pressure FROM pressure_microreactorNG where time between "2011-12-12 16:42" and "2011-12-13 16:43" order by time<br>
	  <b>Latest value:</b><br>
	  1.896e-08 @ 2011-12-13 16:33:53
	</div>
	
	<h2><a href="javascript:toggle('shortlinks')">Make shortlink</a></h2>
	<div id="shortlinks" style="display:none">
	  <form action="../links/link.php?url=checked" method="post">
	    <b>Comment for short link:</b> <input type="text" name="comment"><input type="submit" value="Make short link">
	  </form>
	</div>

      </div>
      <hr>
      
      <div class="copyright">
	<a href="#"><img src="http://www.w3.org/Icons/valid-html401" alt="Valid HTML 4.01 Transitional" height="31" width="88"></a>
      </div>
    </div>
  </body>
</html>
